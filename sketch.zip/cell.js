class cell{

	constructor(){
		this.samplePoints=[];
	}

	isNotEmpty(){
		if(this.samplePoints.length!=0)
		{return true;}
		else 
			return false;
	}
}